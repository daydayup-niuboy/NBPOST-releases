#!/usr/bin/env node
/**
 * NBPost 实况卡片渲染任务执行器（由 Rust 受控拉起，参数数组调用：node render.mjs <job.json>）。
 * 纪律：
 * - 只读取任务 JSON（结构化参数），不拼 shell、不接受命令行内联内容。
 * - 输出只写任务 JSON 的 outputDirectory（导出目录），越界路径直接失败。
 * - 渲染由同一 composition（../scenes）驱动：MP4 + cover.jpg + QA 抽帧同源。
 * - 全部动画按帧计算；本脚本不做任何随机决定（合成 ID 由任务方给出）。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { bundle } from '@remotion/bundler';
import { renderMedia, renderStill, selectComposition } from '@remotion/renderer';

const here = path.dirname(fileURLToPath(import.meta.url));

function emit(event, payload) {
  process.stdout.write(JSON.stringify({ event, ...payload }) + '\n');
}

function fail(message) {
  process.stderr.write('motion-render: ' + message + '\n');
  emit('failed', { error: message });
  process.exit(1);
}

const COMPOSITION_BY_TEMPLATE = {
  'dynamic-cover': 'XhsDynamicCover',
  'dual-compare': 'XhsDualCompare',
};

const EXPECTED = { width: 1080, height: 1440, fps: 30, durationInFrames: 90 };

function validateJob(job) {
  const errors = [];
  if (!job || typeof job !== 'object') return ['任务 JSON 必须是对象。'];
  if (typeof job.taskId !== 'string' || !job.taskId) errors.push('缺少 taskId。');
  if (typeof job.draftRevision !== 'number' || !Number.isInteger(job.draftRevision)) errors.push('draftRevision 必须是整数。');
  if (typeof job.documentKey !== 'string' || !job.documentKey) errors.push('缺少 documentKey。');
  if (!COMPOSITION_BY_TEMPLATE[job.templateId] && !Object.values(COMPOSITION_BY_TEMPLATE).includes(job.compositionId)) {
    errors.push('未知 composition：' + String(job.compositionId));
  }
  if (job.compositionId !== COMPOSITION_BY_TEMPLATE[job.templateId]) errors.push('compositionId 与 templateId 不一致。');
  for (const [key, value] of Object.entries(EXPECTED)) {
    if (job[key] !== value) errors.push(key + ' 必须为 ' + value + '（实况卡片固定契约）。');
  }
  if (!Number.isInteger(job.coverFrame) || job.coverFrame < 0 || job.coverFrame >= EXPECTED.durationInFrames) errors.push('coverFrame 越界。');
  if (typeof job.title !== 'string' || !job.title.trim()) errors.push('标题不能为空。');
  if (!Array.isArray(job.materials)) errors.push('materials 必须是数组。');
  else {
    for (const [index, material] of job.materials.entries()) {
      if (!material || typeof material.assetId !== 'string') errors.push('materials[' + index + '] 缺少 assetId。');
      if (typeof material?.dataUrl !== 'string' || !/^data:image\/(?:png|jpeg|webp);base64,/.test(material.dataUrl)) {
        errors.push('materials[' + index + '] 仅接受受控 data URL 素材。');
      }
    }
  }
  if (typeof job.outputDirectory !== 'string' || !job.outputDirectory) errors.push('缺少 outputDirectory。');
  return errors;
}

function resolveInside(directory, relative) {
  const target = path.resolve(directory, relative);
  const root = path.resolve(directory);
  if (target !== root && !target.startsWith(root + path.sep)) fail('输出越界：' + relative);
  return target;
}

function probe(file) {
  const result = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration:stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames', '-of', 'json', file], { encoding: 'utf8' });
  if (result.error || result.status !== 0) return { available: false, reason: result.error ? String(result.error.message) : 'ffprobe 退出码 ' + result.status };
  try {
    return { available: true, raw: JSON.parse(result.stdout) };
  } catch (error) {
    return { available: false, reason: String(error) };
  }
}

async function main() {
  const jobPath = process.argv[2];
  if (!jobPath) fail('用法：node render.mjs <job.json>');
  let job;
  try {
    job = JSON.parse(await fs.readFile(path.resolve(jobPath), 'utf8'));
  } catch (error) {
    fail('任务 JSON 读取失败：' + (error instanceof Error ? error.message : String(error)));
    return;
  }
  const errors = validateJob(job);
  if (errors.length) fail('任务参数不合法：' + errors.join(' '));
  const outDir = path.resolve(job.outputDirectory);
  await fs.mkdir(outDir, { recursive: true });

  emit('progress', { progress: 0.02, message: '打包 composition' });
  let serveUrl;
  try {
    serveUrl = await bundle({ entryPoint: path.resolve(here, 'index.tsx'), onProgress: step => emit('progress', { progress: 0.02 + step / 100 * 0.18, message: '打包 ' + step + '%' }) });
  } catch (error) {
    fail('composition 打包失败：' + (error instanceof Error ? error.message : String(error)));
    return;
  }

  const inputProps = {
    templateId: job.templateId,
    draft: {
      title: job.title,
      body: job.body ?? '',
      compareItems: job.compareItems ?? [],
      materials: job.materials ?? [],
      paletteId: job.paletteId ?? 'paper',
    },
  };
  const browserExecutable = process.env.NBPOST_MOTION_BROWSER || process.env.LIVECANVAS_BROWSER || undefined;
  const common = { serveUrl, inputProps, browserExecutable };
  let composition;
  try {
    composition = await selectComposition({ ...common, id: job.compositionId });
  } catch (error) {
    fail('composition 选择失败：' + (error instanceof Error ? error.message : String(error)));
    return;
  }
  if (composition.width !== EXPECTED.width || composition.height !== EXPECTED.height || composition.fps !== EXPECTED.fps || composition.durationInFrames !== EXPECTED.durationInFrames) {
    fail('composition 尺寸/帧率/时长与任务契约不符。');
    return;
  }

  const movie = resolveInside(outDir, 'motion.mp4');
  emit('progress', { progress: 0.22, message: '渲染 MP4' });
  try {
    await renderMedia({
      ...common,
      composition,
      codec: 'h264',
      pixelFormat: 'yuv420p',
      crf: 16,
      outputLocation: movie,
      concurrency: 2,
      onProgress: ({ progress }) => emit('progress', { progress: 0.22 + progress * 0.55, message: '渲染 MP4 ' + Math.round(progress * 100) + '%' }),
    });
  } catch (error) {
    fail('MP4 渲染失败：' + (error instanceof Error ? error.message : String(error)));
    return;
  }

  const cover = resolveInside(outDir, 'cover.jpg');
  emit('progress', { progress: 0.8, message: '渲染封面帧 ' + job.coverFrame });
  try {
    await renderStill({ ...common, composition, frame: job.coverFrame, imageFormat: 'jpeg', jpegQuality: 100, output: cover });
  } catch (error) {
    fail('封面渲染失败：' + (error instanceof Error ? error.message : String(error)));
    return;
  }

  emit('progress', { progress: 0.86, message: '渲染 QA 抽帧' });
  const qaFrames = Array.isArray(job.qaFrames) && job.qaFrames.length ? job.qaFrames : [0, Math.floor(EXPECTED.durationInFrames / 2), job.coverFrame];
  const qaFiles = [];
  for (const frame of qaFrames) {
    if (!Number.isInteger(frame) || frame < 0 || frame >= EXPECTED.durationInFrames) fail('QA 帧越界：' + frame);
    const file = resolveInside(outDir, 'frame-' + frame + '.png');
    await renderStill({ ...common, composition, frame, imageFormat: 'png', output: file });
    qaFiles.push({ frame, file: path.basename(file) });
  }

  for (const name of ['motion.mp4', 'cover.jpg']) {
    const stat = await fs.stat(resolveInside(outDir, name));
    if (stat.size === 0) fail('渲染产物为空：' + name);
  }

  const movieProbe = probe(movie);
  const coverProbe = probe(cover);
  const renderReport = {
    taskId: job.taskId,
    documentKey: job.documentKey,
    draftId: job.draftId,
    draftRevision: job.draftRevision,
    compositionId: job.compositionId,
    width: composition.width,
    height: composition.height,
    fps: composition.fps,
    durationInFrames: composition.durationInFrames,
    coverFrame: job.coverFrame,
    coverTime: job.coverFrame / composition.fps,
    coverIsHoldFrame: job.coverFrame >= job.holdFromFrame,
    movieProbe,
    coverProbe,
    qaFiles,
  };
  await fs.writeFile(resolveInside(outDir, 'render.json'), JSON.stringify(renderReport, null, 2), 'utf8');
  const qaReport = {
    data: { structural: 'passed', factCheck: 'not_tested' },
    render: { video: movieProbe.available ? 'passed' : 'not_tested', cover: coverProbe.available ? 'passed' : 'not_tested', visualReview: 'not_tested' },
    livePhoto: { metadata: 'not_tested', localLoad: 'not_tested', package: 'not_tested', photosImport: 'not_requested', macPlayback: 'not_tested', iPhonePlayback: 'not_tested' },
    notes: movieProbe.available ? [] : ['ffprobe 不可用：' + String(movieProbe.reason)],
  };
  await fs.writeFile(resolveInside(outDir, 'qa.json'), JSON.stringify(qaReport, null, 2), 'utf8');
  emit('progress', { progress: 1, message: '渲染完成', coverTime: renderReport.coverTime, renderJson: path.join(outDir, 'render.json') });
  emit('render-done', { movie, cover, renderJson: path.join(outDir, 'render.json') });
}

main().catch(error => fail(error instanceof Error ? error.stack ?? error.message : String(error)));
