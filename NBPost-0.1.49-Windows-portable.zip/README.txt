NBPost 0.1.49
运行 NBPost.exe；MCP 辅助程序 nbpost-mcp.exe 与主程序放在同一目录。构建来源见“关于”与 BUILD-INFO.txt。
小红书实况卡片需要 Node.js、Python 3.10+、Pillow 10/11、FFmpeg 和浏览器；首次启用前，在 engine/motion-engine 目录执行 npm ci。
请备份重要文档。此目录不表示配置和数据均存放在程序目录。
