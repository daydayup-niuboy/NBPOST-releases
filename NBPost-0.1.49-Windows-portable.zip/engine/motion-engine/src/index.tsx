/**
 * Remotion composition 根：动态封面 + 双项对比。
 * 场景实现来自 ../../scenes（与应用内预览同一份源码），此处只做 Remotion 包装：
 * useCurrentFrame 取帧、delayRender 等素材解码完成，保证预览/封面/MP4 同源。
 */
import React, { useEffect, useState } from 'react';
import { AbsoluteFill, Composition, continueRender, delayRender, registerRoot, useCurrentFrame, useVideoConfig } from 'remotion';
import { MotionScene } from '../../scenes/MotionScene';
import type { SceneInput } from '../../scenes/sceneTypes';

export interface MotionCompositionProps {
  templateId: 'dynamic-cover' | 'dual-compare';
  draft: SceneInput;
}

const FRAME = { width: 1080, height: 1440, fps: 30, durationInFrames: 90 };

/** Remotion 4 的 Composition 组件签名是宽松 props；这里只做一次收窄，不改变场景实现。 */
const SceneHost: React.FC<Record<string, unknown>> = input => {
  const { templateId, draft } = input as unknown as MotionCompositionProps;
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const [handle] = useState(() => delayRender('load-materials'));
  useEffect(() => {
    let cancelled = false;
    const images = draft.materials.map(material => {
      const image = new Image();
      image.src = material.dataUrl;
      return image.decode ? image.decode().catch(() => undefined) : Promise.resolve();
    });
    Promise.all(images).then(() => {
      if (!cancelled) continueRender(handle);
    });
    return () => {
      cancelled = true;
    };
  }, [draft.materials, handle]);
  return (
    <AbsoluteFill style={{ background: '#ffffff' }}>
      <MotionScene templateId={templateId} draft={draft} frame={frame} fps={fps} width={width} height={height} />
    </AbsoluteFill>
  );
};

const emptyDraft: SceneInput = { title: 'NBPost 实况卡片', body: '', compareItems: [], materials: [], paletteId: 'paper' };

export const Root: React.FC = () => (
  <>
    <Composition
      id="XhsDynamicCover"
      component={SceneHost}
      width={FRAME.width}
      height={FRAME.height}
      fps={FRAME.fps}
      durationInFrames={FRAME.durationInFrames}
      defaultProps={{ templateId: 'dynamic-cover' as const, draft: emptyDraft }}
    />
    <Composition
      id="XhsDualCompare"
      component={SceneHost}
      width={FRAME.width}
      height={FRAME.height}
      fps={FRAME.fps}
      durationInFrames={FRAME.durationInFrames}
      defaultProps={{ templateId: 'dual-compare' as const, draft: emptyDraft }}
    />
  </>
);

registerRoot(Root);
